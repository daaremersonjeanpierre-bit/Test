# Gestion Business EDS
Application de gestion professionnelle hors ligne, créée par Emerson Digital Solution.

**Slogan :** Des solutions digitales pour booster votre business en ligne  
**Site :** https://emersondigitalsolution.vercel.app/

## Fonctionnalités
- Tableau de bord avec indicateurs et graphique des ventes.
- Produits, services, stocks et seuils d'alerte.
- Clients et fournisseurs.
- Ventes, encaissements, soldes et mise à jour du stock.
- Dépenses catégorisées.
- Dettes et créances avec paiements partiels.
- Reçus/factures imprimables à partir des ventes.
- Tâches et échéances.
- Rapports par mois et export CSV des ventes.
- Sauvegarde/restauration JSON.
- Paramètres de l'entreprise, devise et thème clair/sombre.
- Page « À propos de nous » et lien vers le site officiel.
- Interface responsive pour mobile, tablette et ordinateur.

## Démarrage
Ouvrir `index.html` dans Acode ou importer le projet dans un convertisseur HTML-to-APK acceptant les fichiers locaux. Lire `documentation/INSTALLATION.md`.

## Important
Application hors ligne, sans comptes ni synchronisation. Les données sont conservées sur l'appareil : exporter régulièrement une sauvegarde. Ce logiciel n'est pas un outil de comptabilité certifié.

## Langues
L'application propose maintenant deux langues d'interface : français et kreyòl ayisyen. Appuyez sur le bouton **Kreyòl / Français** dans la barre supérieure pour changer la langue. Le choix est mémorisé sur l'appareil. Les données saisies (noms de clients, produits, notes, etc.) ne sont pas traduites ni modifiées.
