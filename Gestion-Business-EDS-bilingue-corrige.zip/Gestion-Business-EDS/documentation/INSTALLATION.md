# Gestion Business EDS — installation

## Présentation
Application de gestion polyvalente locale créée par Emerson Digital Solution.
Slogan : « Des solutions digitales pour booster votre business en ligne ».

## Utilisation dans Acode
1. Extraire l'archive ZIP dans un dossier.
2. Ouvrir le dossier extrait dans Acode.
3. Lancer `index.html` avec l'aperçu / serveur local d'Acode.
4. Vérifier les modules : produits, clients, ventes, dépenses, dettes, tâches, rapports et sauvegardes.

## Conversion en APK
1. Importer les fichiers du projet dans un convertisseur HTML-to-APK qui accepte les ressources locales.
2. Définir `index.html` comme page d'accueil.
3. Autoriser JavaScript et vérifier la prise en charge de IndexedDB dans le WebView.
4. Tester l'enregistrement des données, la fermeture et la réouverture de l'application, l'exportation et l'importation d'une sauvegarde.
5. Si le convertisseur demande une URL, utiliser un hébergement HTTPS permet de charger la page, mais le fonctionnement hors ligne devra être testé séparément. Une simple page distante ne garantit pas le mode hors ligne.

## Données et confidentialité
- Les données sont stockées localement dans IndexedDB, avec un repli sur localStorage si IndexedDB n'est pas disponible.
- Il n'y a ni compte utilisateur, ni serveur, ni synchronisation distante.
- Les données locales peuvent être supprimées par la désinstallation ou l'effacement des données de l'application. Exportez régulièrement une sauvegarde JSON.
- L'importation d'une sauvegarde remplace les données locales correspondantes. Faites une sauvegarde avant restauration.

## Limites à connaître
- Il s'agit d'un outil de gestion généraliste, pas d'un logiciel de comptabilité certifié.
- Les factures imprimables sont des documents simples générés à partir des ventes.
- La vente enregistre un seul produit/service par transaction dans cette première version.
- Le suivi des créances créées depuis une vente est disponible ; le paiement actualise le solde de vente.
- Aucun paiement réel n'est traité par l'application.
- Les données ne sont pas synchronisées entre plusieurs appareils.

## Marque
Créé par Emerson Digital Solution.
« Des solutions digitales pour booster votre business en ligne ».
Site : https://emersondigitalsolution.vercel.app/

### Changer la langue
Dans l'application, utilisez le bouton **Kreyòl / Français** en haut de l'écran. Le choix reste mémorisé sur cet appareil. Certaines expressions techniques ou certains messages ajoutés ultérieurement peuvent rester en français.
