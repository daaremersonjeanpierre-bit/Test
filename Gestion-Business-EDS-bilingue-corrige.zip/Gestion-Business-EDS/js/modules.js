/* Rendu des pages et opérations métier. Aucun service distant requis. */
(function(){
const E=window.EDS;
const $=s=>document.querySelector(s);
const root=()=>$('#viewRoot');
const views={
 dashboard:['Tableau de bord','Votre activité en un coup d’œil.'],
 sales:['Ventes','Enregistrez les ventes et suivez les paiements.'],
 products:['Produits & services','Gérez votre catalogue, vos prix et vos coûts.'],
 inventory:['Stocks & inventaire','Surveillez les quantités et les produits à réapprovisionner.'],
 customers:['Clients','Organisez vos contacts et les soldes à recevoir.'],
 suppliers:['Fournisseurs','Suivez vos fournisseurs et les achats.'],
 debts:['Dettes & créances','Gardez une vue claire sur les montants dus.'],
 expenses:['Dépenses','Suivez les sorties d’argent de votre activité.'],
 invoices:['Factures & reçus','Consultez et imprimez les documents issus des ventes.'],
 tasks:['Tâches','Organisez les actions à effectuer.'],
 reports:['Rapports','Analysez les ventes et les dépenses enregistrées.'],
 backup:['Sauvegarde','Exportez et restaurez vos données locales.'],
 settings:['Paramètres','Personnalisez votre espace de gestion.'],
 about:['À propos de nous','Découvrez Emerson Digital Solution.']
};
const fmt=(n)=>E.currency(n);
const moneyField=(label,name,required=true)=>`<div class="field"><label>${label}${required?' *':''}</label><input name="${name}" type="number" step="0.01" min="0" ${required?'required':''} value="0"></div>`;
const field=(label,name,opts={})=>`<div class="field ${opts.full?'full':''}"><label>${label}${opts.required?' *':''}</label>${opts.type==='select'?`<select name="${name}" ${opts.required?'required':''}>${(opts.options||[]).map(o=>`<option value="${E.esc(o.value)}">${E.esc(o.label)}</option>`).join('')}</select>`:opts.type==='textarea'?`<textarea name="${name}" ${opts.required?'required':''} placeholder="${E.esc(opts.placeholder||'')}"></textarea>`:`<input name="${name}" type="${opts.type||'text'}" ${opts.required?'required':''} placeholder="${E.esc(opts.placeholder||'')}" ${opts.value!==undefined?`value="${E.esc(opts.value)}"`:''} ${opts.min!==undefined?`min="${opts.min}"`:''} ${opts.step?`step="${opts.step}"`:''}>`}</div>`;
function heading(title,desc,action=''){return `<div class="page-heading"><div><div class="eyebrow">GESTION BUSINESS EDS</div><h1>${title}</h1><p>${desc}</p></div>${action?`<div class="heading-actions">${action}</div>`:''}</div>`;}
function button(label,action,kind='accent',icon='＋'){return `<button class="btn btn-${kind}" data-action="${action}">${icon?`<span>${icon}</span>`:''}${label}</button>`;}
function stat(label,value,icon,foot='Mis à jour localement'){return `<article class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></article>`;}
function empty(title,desc,action='',icon='▧'){return `<div class="empty-state"><div class="empty-icon">${icon}</div><strong>${title}</strong><p>${desc}</p>${action}</div>`;}
function table(headers,rows,emptyHtml){return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.length?rows.join(''):`<tr><td colspan="${headers.length}">${emptyHtml||empty('Aucune donnée','Ajoutez votre premier élément pour commencer.')}</td></tr>`}</tbody></table></div>`;}
function rowActions(store,item){return `<div style="display:flex;gap:5px"><button class="icon-action" title="Modifier" data-edit="${store}" data-id="${item.id}">✎</button><button class="icon-action" title="Supprimer" data-delete="${store}" data-id="${item.id}">×</button></div>`;}
function badge(text,type=''){return `<span class="badge ${type}">${E.esc(text)}</span>`;}
function itemTitle(name,sub=''){return `<div class="cell-title">${E.esc(name||'Sans nom')}</div>${sub?`<div class="cell-sub">${E.esc(sub)}</div>`:''}`;}
function modal(title,subtitle,body,submitLabel='Enregistrer',onSubmit=null){
 const mr=$('#modalRoot');mr.innerHTML=`<div class="modal-card" role="dialog" aria-modal="true"><div class="modal-header"><div><h2>${title}</h2><p>${subtitle||''}</p></div><button class="icon-button" data-close-modal>✕</button></div><form id="entityForm"><div class="modal-body">${body}</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-close-modal>Annuler</button><button class="btn btn-accent" type="submit">${submitLabel}</button></div></form></div>`;
 mr.querySelector('[data-close-modal]').focus();
 mr.querySelectorAll('[data-close-modal]').forEach(b=>b.addEventListener('click',()=>mr.innerHTML=''));
 mr.querySelector('#entityForm').addEventListener('submit',async ev=>{ev.preventDefault();const fd=new FormData(ev.currentTarget);const data=Object.fromEntries(fd.entries());try{await onSubmit(data);mr.innerHTML='';await render(E.currentView);E.toast('Enregistrement effectué.');}catch(err){E.toast(err.message||'Une erreur est survenue.','error');}});
}
function askConfirm(message,onYes){modal('Confirmer la suppression',message,`<div class="notice warning"><strong>Attention :</strong> cette action est définitive sur cet appareil.</div>`,'Supprimer',async()=>{await onYes();});}
async function get(name){return E.all(name);}
async function openEntityForm(store,id=null){
 const defs={
 products:{title:'Produit ou service',subtitle:'Complétez les informations du catalogue.',fields:[field('Nom','name',{required:true}),field('Catégorie','category',{placeholder:'Ex. Accessoires'}),field('Type','type',{type:'select',options:[{value:'product',label:'Produit physique'},{value:'service',label:'Service'}]}),moneyField('Prix de vente','price'),moneyField('Coût unitaire','cost'),field('Quantité en stock','stock',{type:'number',value:'0',min:0,step:'1'}),field('Seuil d’alerte','lowStock',{type:'number',value:String(E.settings.lowStock||5),min:0,step:'1'}),field('Référence / SKU','sku'),field('Description','description',{type:'textarea',full:true})],store:'products'},
 customers:{title:'Client',subtitle:'Ajoutez un contact client.',fields:[field('Nom complet / entreprise','name',{required:true}),field('Téléphone','phone',{type:'tel'}),field('E-mail','email',{type:'email'}),field('Adresse','address'),field('Solde initial dû','balance',{type:'number',value:'0',min:0,step:'0.01'}),field('Notes','notes',{type:'textarea',full:true})],store:'customers'},
 suppliers:{title:'Fournisseur',subtitle:'Ajoutez un partenaire fournisseur.',fields:[field('Nom du fournisseur','name',{required:true}),field('Téléphone','phone',{type:'tel'}),field('E-mail','email',{type:'email'}),field('Adresse','address'),field('Contact principal','contact'),field('Notes','notes',{type:'textarea',full:true})],store:'suppliers'},
 expenses:{title:'Nouvelle dépense',subtitle:'Enregistrez une sortie d’argent.',fields:[field('Libellé','name',{required:true}),field('Catégorie','category',{type:'select',options:[{value:'Achats',label:'Achats'},{value:'Transport',label:'Transport'},{value:'Loyer',label:'Loyer'},{value:'Salaires',label:'Salaires'},{value:'Internet et téléphone',label:'Internet et téléphone'},{value:'Équipement',label:'Équipement'},{value:'Autre',label:'Autre'}]}),moneyField('Montant','amount'),field('Date','date',{type:'date',required:true,value:E.today()}),field('Mode de paiement','method',{type:'select',options:[{value:'Espèces',label:'Espèces'},{value:'NatCash',label:'NatCash'},{value:'MonCash',label:'MonCash'},{value:'Virement',label:'Virement'},{value:'Autre',label:'Autre'}]}),field('Note','note',{type:'textarea',full:true})],store:'expenses'},
 tasks:{title:'Nouvelle tâche',subtitle:'Planifiez une action.',fields:[field('Titre','name',{required:true}),field('Échéance','dueDate',{type:'date',required:true,value:E.today()}),field('Priorité','priority',{type:'select',options:[{value:'Normale',label:'Normale'},{value:'Haute',label:'Haute'},{value:'Urgente',label:'Urgente'}]}),field('Statut','status',{type:'select',options:[{value:'À faire',label:'À faire'},{value:'En cours',label:'En cours'},{value:'Terminée',label:'Terminée'}]}),field('Description','description',{type:'textarea',full:true})],store:'tasks'}
 };
 const d=defs[store];if(!d)return;
 let old=null;if(id){old=(await get(store)).find(x=>x.id===id);}
 let body=d.fields.join('');
 if(old){for(const [key,val] of Object.entries(old)){const escaped=E.esc(val??'');body=body.replace(new RegExp(`(name="${key}"[^>]*)(>)`),`$1 value="${escaped}"$2`);body=body.replace(new RegExp(`(<textarea name="${key}"[^>]*>)[\\s\\S]*?(</textarea>)`),`$1${escaped}$2`);body=body.replace(new RegExp(`(<select name="${key}"[^>]*>)`),`$1`);}}
 modal(old?'Modifier : '+d.title:d.title,d.subtitle,`<div class="form-grid">${body}</div>`,old?'Mettre à jour':'Enregistrer',async data=>{
  Object.keys(data).forEach(k=>{if(['price','cost','stock','lowStock','balance','amount'].includes(k))data[k]=Number(data[k]||0);});
  if(store==='products'){data.stock=Math.max(0,Number(data.stock||0));data.lowStock=Number(data.lowStock??E.settings.lowStock);}
  if(old)data.id=old.id;
  await E.save(store,{...old,...data});
 });
}
async function openSaleForm(){
 const products=await get('products'),customers=await get('customers');
 if(!products.length){E.toast('Ajoutez d’abord un produit ou service.','error');E.currentView='products';await render('products');return;}
 const body=`<div class="form-grid">${field('Client','customerId',{type:'select',options:[{value:'',label:'Client de passage'},...customers.map(c=>({value:c.id,label:c.name}))]})}${field('Produit ou service','productId',{type:'select',required:true,options:products.map(p=>({value:p.id,label:`${p.name} — ${fmt(p.price)} (stock : ${p.stock??0})`}))})}${field('Quantité','quantity',{type:'number',required:true,value:'1',min:1,step:'1'})}${field('Prix unitaire','unitPrice',{type:'number',required:true,value:String(products[0].price||0),min:0,step:'0.01'})}${field('Réduction','discount',{type:'number',value:'0',min:0,step:'0.01'})}${field('Montant payé','paid',{type:'number',required:true,value:'0',min:0,step:'0.01'})}${field('Date de vente','date',{type:'date',required:true,value:E.today()})}${field('Mode de paiement','method',{type:'select',options:[{value:'Espèces',label:'Espèces'},{value:'NatCash',label:'NatCash'},{value:'MonCash',label:'MonCash'},{value:'Virement',label:'Virement'},{value:'Crédit',label:'Crédit'},{value:'Autre',label:'Autre'}]})}${field('Note','note',{type:'textarea',full:true})}</div><div class="notice" style="margin-top:14px">Le stock sera mis à jour après validation. Le bénéfice estimé utilise le coût unitaire du produit, et n’est pas égal au montant encaissé.</div>`;
 modal('Enregistrer une vente','Saisissez les détails de la transaction.',body,'Valider la vente',async data=>{
  const p=products.find(x=>x.id===data.productId);if(!p)throw new Error('Produit introuvable.');
  const qty=Number(data.quantity),price=Number(data.unitPrice),discount=Number(data.discount||0),total=Math.max(0,qty*price-discount),paid=Number(data.paid||0);
  if(qty<=0)throw new Error('La quantité doit être supérieure à zéro.');
  if(p.type!=='service'&&qty>Number(p.stock||0))throw new Error('Stock insuffisant. Ajustez le stock avant cette vente.');
  if(paid>total)throw new Error('Le montant payé ne peut pas dépasser le total de la vente.');
  const customer=customers.find(c=>c.id===data.customerId);
  const sale={id:E.id(),productId:p.id,productName:p.name,customerId:customer?.id||'',customerName:customer?.name||'Client de passage',quantity:qty,unitPrice:price,cost:Number(p.cost||0),discount,total,paid,balance:total-paid,profit:(price-Number(p.cost||0))*qty-discount,date:data.date,method:data.method,status:paid>=total?'Payée':paid>0?'Partiellement payée':'Non payée',note:data.note||''};
  await E.save('sales',sale);
  if(p.type!=='service'){p.stock=Number(p.stock||0)-qty;await E.save('products',p);}
  if(customer&&sale.balance>0){await E.save('debts',{id:E.id(),type:'Créance client',partyId:customer.id,partyName:customer.name,sourceId:sale.id,amount:sale.balance,paid:0,balance:sale.balance,date:data.date,dueDate:'',status:'À recevoir',note:'Créance créée par une vente'});}
 });
}
async function paymentForm(debtId){
 const debts=await get('debts'),debt=debts.find(d=>d.id===debtId);if(!debt)return;
 modal('Enregistrer un paiement','Le paiement sera ajouté au suivi de la créance ou dette.',`<div class="notice" style="margin-bottom:15px"><strong>${E.esc(debt.partyName||'Contact')}</strong><br>Solde restant : ${fmt(debt.balance??debt.amount)}</div><div class="form-grid">${field('Montant reçu / payé','amount',{type:'number',required:true,value:String(debt.balance??debt.amount),min:.01,step:'0.01'})}${field('Date','date',{type:'date',required:true,value:E.today()})}${field('Mode de paiement','method',{type:'select',options:[{value:'Espèces',label:'Espèces'},{value:'NatCash',label:'NatCash'},{value:'MonCash',label:'MonCash'},{value:'Virement',label:'Virement'},{value:'Autre',label:'Autre'}]})}</div>`,'Enregistrer le paiement',async data=>{
  const amount=Number(data.amount),bal=Number(debt.balance??debt.amount);if(amount<=0||amount>bal)throw new Error('Montant de paiement invalide.');
  debt.paid=Number(debt.paid||0)+amount;debt.balance=bal-amount;debt.status=debt.balance<=0?'Soldée':debt.type==='Dette fournisseur'?'À payer':'À recevoir';debt.lastPaymentDate=data.date;debt.lastPaymentMethod=data.method;
  await E.save('debts',debt);
  if(debt.sourceId){const sales=await get('sales'),sale=sales.find(s=>s.id===debt.sourceId);if(sale){sale.paid=Number(sale.paid||0)+amount;sale.balance=Math.max(0,sale.total-sale.paid);sale.status=sale.balance===0?'Payée':'Partiellement payée';await E.save('sales',sale);}}
 });
}
async function dashboard(){
 const [sales,products,customers,expenses,debts,tasks]=await Promise.all(['sales','products','customers','expenses','debts','tasks'].map(get));
 const month=E.monthKey(),ms=sales.filter(s=>E.monthKey(s.date)===month),me=expenses.filter(x=>E.monthKey(x.date)===month);
 const revenue=E.sum(ms,s=>s.total),received=E.sum(ms,s=>s.paid),spent=E.sum(me,x=>x.amount),profit=E.sum(ms,s=>s.profit)-spent;
 const low=products.filter(p=>p.type!=='service'&&Number(p.stock||0)<=Number(p.lowStock??E.settings.lowStock));
 const pending=debts.filter(d=>Number(d.balance??d.amount)>0);
 const recent=[...sales].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,6);
 const monthBars=[];for(let i=5;i>=0;i--){const d=new Date();d.setDate(1);d.setMonth(d.getMonth()-i);const key=d.toISOString().slice(0,7);monthBars.push({key,label:d.toLocaleDateString('fr-FR',{month:'short'}),value:E.sum(sales.filter(s=>E.monthKey(s.date)===key),s=>s.total)});}
 const max=Math.max(1,...monthBars.map(x=>x.value));
 return heading('Tableau de bord','Voici le résumé de votre activité pour '+new Date().toLocaleDateString('fr-FR',{month:'long',year:'numeric'}),button('Nouvelle vente','new-sale','accent','＋'))+
 `<div class="grid stats-grid">${stat('Chiffre d’affaires',fmt(revenue),'↗','Total des ventes ce mois')}${stat('Montant encaissé',fmt(received),'＄','Paiements enregistrés ce mois')}${stat('Dépenses',fmt(spent),'↘','Dépenses enregistrées ce mois')}${stat('Résultat estimé',fmt(profit),'⌁','Bénéfice estimé moins dépenses')}</div>
 <div class="grid dashboard-grid"><section class="panel"><div class="panel-header"><div><h2>Évolution des ventes</h2><p>Chiffre d’affaires sur les 6 derniers mois</p></div><span class="pill">6 mois</span></div><div class="chart-wrap"><canvas id="salesChart" aria-label="Graphique des ventes sur six mois"></canvas></div></section>
 <section class="panel"><div class="panel-header"><div><h2>Actions rapides</h2><p>Accédez aux opérations courantes</p></div></div><div class="quick-grid"><button class="quick-action" data-action="new-sale"><span class="quick-icon">↗</span><span><strong>Nouvelle vente</strong><small>Enregistrer un paiement</small></span></button><button class="quick-action" data-action="new-product"><span class="quick-icon">▤</span><span><strong>Ajouter un produit</strong><small>Mettre à jour le catalogue</small></span></button><button class="quick-action" data-action="new-customer"><span class="quick-icon">♙</span><span><strong>Ajouter un client</strong><small>Créer une fiche contact</small></span></button><button class="quick-action" data-action="new-expense"><span class="quick-icon">↘</span><span><strong>Ajouter une dépense</strong><small>Suivre les sorties</small></span></button></div></section></div>
 <div class="grid dashboard-grid"><section class="panel table-panel"><div class="panel-header"><div><h2>Transactions récentes</h2><p>Les dernières ventes enregistrées</p></div><button class="btn btn-secondary btn-sm" data-nav="sales">Voir tout ↗</button></div>${table(['Transaction','Client','Date','Total','Statut'],recent.map(s=>`<tr><td>${itemTitle(s.productName,'Vente #'+s.id.slice(-6).toUpperCase())}</td><td>${E.esc(s.customerName||'Client de passage')}</td><td>${E.shortDate(s.date)}</td><td><b>${fmt(s.total)}</b></td><td>${badge(s.status||'Enregistrée',s.balance>0?'warning':'success')}</td></tr>`),empty('Aucune vente enregistrée','Vos transactions apparaîtront ici.',button('Créer une vente','new-sale','accent','＋')))}</section>
 <section class="panel"><div class="panel-header"><div><h2>Alertes & suivi</h2><p>Points nécessitant votre attention</p></div></div><div class="list-stack">
 <div class="list-row"><span class="list-avatar">▤</span><div class="list-main"><strong>Stocks bas</strong><small>${low.length} produit(s) au seuil d’alerte</small></div><div class="list-value">${low.length?badge('À vérifier','warning'):badge('Tout va bien','success')}</div></div>
 <div class="list-row"><span class="list-avatar">⇄</span><div class="list-main"><strong>Soldes en attente</strong><small>Créances et dettes non soldées</small></div><div class="list-value">${pending.length}</div></div>
 <div class="list-row"><span class="list-avatar">☑</span><div class="list-main"><strong>Tâches ouvertes</strong><small>Actions à faire ou en cours</small></div><div class="list-value">${tasks.filter(t=>t.status!=='Terminée').length}</div></div>
 <div class="list-row"><span class="list-avatar">♙</span><div class="list-main"><strong>Clients enregistrés</strong><small>Contacts dans votre base locale</small></div><div class="list-value">${customers.length}</div></div>
 </div></section></div>`;
}
async function listingPage(view){
 const config={
 inventory:{store:'products',title:'Stocks & inventaire',desc:'Surveillez les quantités disponibles et repérez les produits à réapprovisionner.',add:'Nouveau produit',action:'new-product',headers:['Produit','Référence','Stock actuel','Seuil d’alerte','Prix de vente','État','Actions'],rows:items=>items.map(p=>`<tr><td>${itemTitle(p.name,p.category||'')}</td><td>${E.esc(p.sku||'—')}</td><td><b>${Number(p.stock||0)}</b></td><td>${Number(p.lowStock??E.settings.lowStock)}</td><td>${fmt(p.price)}</td><td>${Number(p.stock||0)<=Number(p.lowStock??E.settings.lowStock)?badge('Réapprovisionner','warning'):badge('Disponible','success')}</td><td>${rowActions('products',p)}</td></tr>`)},
 products:{store:'products',title:'Produits & services',desc:'Gérez votre catalogue, vos coûts et vos prix de vente.',add:'Nouveau produit',action:'new-product',headers:['Produit','Catégorie','Type','Prix de vente','Coût','Stock','Actions'],rows:items=>items.map(p=>`<tr><td>${itemTitle(p.name,p.sku||p.description||'')}</td><td>${E.esc(p.category||'—')}</td><td>${badge(p.type==='service'?'Service':'Produit')}</td><td><b>${fmt(p.price)}</b></td><td>${fmt(p.cost)}</td><td>${p.type==='service'?'—':badge(String(p.stock??0),Number(p.stock||0)<=Number(p.lowStock??E.settings.lowStock)?'warning':'success')}</td><td>${rowActions('products',p)}</td></tr>`)},
 customers:{store:'customers',title:'Clients',desc:'Centralisez les coordonnées et le suivi de vos clients.',add:'Nouveau client',action:'new-customer',headers:['Client','Téléphone','E-mail','Solde initial','Actions'],rows:items=>items.map(p=>`<tr><td>${itemTitle(p.name,p.address)}</td><td>${E.esc(p.phone||'—')}</td><td>${E.esc(p.email||'—')}</td><td>${fmt(p.balance)}</td><td>${rowActions('customers',p)}</td></tr>`)},
 suppliers:{store:'suppliers',title:'Fournisseurs',desc:'Gardez les informations de vos partenaires à portée de main.',add:'Nouveau fournisseur',action:'new-supplier',headers:['Fournisseur','Contact','Téléphone','E-mail','Actions'],rows:items=>items.map(p=>`<tr><td>${itemTitle(p.name,p.address)}</td><td>${E.esc(p.contact||'—')}</td><td>${E.esc(p.phone||'—')}</td><td>${E.esc(p.email||'—')}</td><td>${rowActions('suppliers',p)}</td></tr>`)},
 expenses:{store:'expenses',title:'Dépenses',desc:'Suivez les sorties d’argent et catégorisez vos frais.',add:'Nouvelle dépense',action:'new-expense',headers:['Dépense','Catégorie','Date','Mode','Montant','Actions'],rows:items=>items.map(p=>`<tr><td>${itemTitle(p.name,p.note)}</td><td>${E.esc(p.category||'—')}</td><td>${E.shortDate(p.date)}</td><td>${E.esc(p.method||'—')}</td><td class="money-negative"><b>− ${fmt(p.amount)}</b></td><td>${rowActions('expenses',p)}</td></tr>`)},
 tasks:{store:'tasks',title:'Tâches',desc:'Organisez le travail et suivez les échéances.',add:'Nouvelle tâche',action:'new-task',headers:['Tâche','Échéance','Priorité','Statut','Actions'],rows:items=>items.map(p=>`<tr><td>${itemTitle(p.name,p.description)}</td><td>${E.shortDate(p.dueDate)}</td><td>${badge(p.priority||'Normale',p.priority==='Urgente'?'danger':p.priority==='Haute'?'warning':'')}</td><td>${badge(p.status||'À faire',p.status==='Terminée'?'success':p.status==='En cours'?'warning':'')}</td><td><div style="display:flex;gap:5px"><button class="btn btn-secondary btn-sm" data-toggle-task="${p.id}">${p.status==='Terminée'?'Réouvrir':'Terminer'}</button>${rowActions('tasks',p)}</div></td></tr>`)}
 };
 const c=config[view];if(!c)return '';
 const items=await get(c.store);let shown=items;
 if(view==='inventory')shown=(await get('products')).filter(p=>p.type!=='service');
 const actual=c.store==='products'&&view==='inventory'?'products':c.store;
 const total=shown.length;
 const extra=view==='products'?`<span class="pill">${shown.filter(p=>p.type==='service').length} service(s)</span>`:view==='inventory'?`<span class="pill">${shown.filter(p=>Number(p.stock||0)<=Number(p.lowStock??E.settings.lowStock)).length} alerte(s)</span>`:'';
 const rows=c.rows(shown);
 return heading(c.title,c.desc,button(c.add,c.action,'accent','＋'))+`<section class="panel table-panel"><div class="panel-header"><div><h2>${view==='inventory'?'Niveaux de stock':c.title+' enregistrés'}</h2><p>${total} élément(s) dans votre espace local</p></div><div class="table-tools"><input class="table-search" id="listSearch" placeholder="Rechercher dans la liste…" type="search">${extra}</div></div>${table(c.headers,rows,empty('Aucun élément pour le moment','Ajoutez un élément pour commencer.',button(c.add,c.action,'accent','＋')))}<div class="table-bottom"><span>${total} résultat(s)</span><span>Stockage local · hors ligne</span></div></section>`;
}
async function salesPage(){
 const sales=await get('sales'),total=E.sum(sales,s=>s.total),paid=E.sum(sales,s=>s.paid),balance=E.sum(sales,s=>s.balance);
 const rows=sales.map(s=>`<tr><td>${itemTitle(s.productName,'#'+s.id.slice(-7).toUpperCase())}</td><td>${E.esc(s.customerName||'Client de passage')}</td><td>${E.shortDate(s.date)}</td><td>${s.quantity}</td><td><b>${fmt(s.total)}</b></td><td>${fmt(s.paid)}</td><td>${badge(s.status||'Enregistrée',s.balance>0?'warning':'success')}</td><td>${rowActions('sales',s)}</td></tr>`);
 return heading('Ventes','Consultez les transactions, les montants encaissés et les soldes.',button('Nouvelle vente','new-sale','accent','＋'))+
 `<div class="grid stats-grid">${stat('Ventes enregistrées',sales.length,'↗','Nombre de transactions')}${stat('Chiffre d’affaires',fmt(total),'＄','Total des ventes')}${stat('Encaissé',fmt(paid),'✓','Paiements reçus')}${stat('Reste à recevoir',fmt(balance),'⇄','Soldes ouverts')}</div><section class="panel table-panel"><div class="panel-header"><div><h2>Historique des ventes</h2><p>Chaque transaction met à jour les stocks concernés.</p></div><input class="table-search" id="listSearch" placeholder="Rechercher…" type="search"></div>${table(['Produit','Client','Date','Qté','Total','Payé','Statut','Actions'],rows,empty('Aucune vente','Enregistrez votre première vente.',button('Nouvelle vente','new-sale','accent','＋')))}<div class="table-bottom"><span>${sales.length} vente(s)</span><span>Les ventes et encaissements sont suivis séparément.</span></div></section>`;
}
async function inventoryPage(){return listingPage('inventory');}
async function debtsPage(){
 const debts=await get('debts'),open=debts.filter(d=>Number(d.balance??d.amount)>0),receivable=E.sum(open.filter(d=>d.type!=='Dette fournisseur'),d=>d.balance??d.amount),payable=E.sum(open.filter(d=>d.type==='Dette fournisseur'),d=>d.balance??d.amount);
 const rows=debts.map(d=>`<tr><td>${itemTitle(d.partyName,d.type)}</td><td>${E.shortDate(d.date)}</td><td>${fmt(d.amount)}</td><td>${fmt(d.paid||0)}</td><td><b>${fmt(d.balance??d.amount)}</b></td><td>${badge(d.status||'En attente',(d.balance??d.amount)<=0?'success':'warning')}</td><td><div style="display:flex;gap:5px">${(d.balance??d.amount)>0?`<button class="btn btn-secondary btn-sm" data-payment="${d.id}">Paiement</button>`:''}${rowActions('debts',d)}</div></td></tr>`);
 return heading('Dettes & créances','Suivez ce que vos clients vous doivent et ce que vous devez aux fournisseurs.',`<button class="btn btn-secondary" data-action="new-debt">＋ Ajouter un solde</button>`)+
 `<div class="grid stats-grid">${stat('Créances à recevoir',fmt(receivable),'↗','Montants dus à votre entreprise')}${stat('Dettes à payer',fmt(payable),'↘','Montants dus aux fournisseurs')}${stat('Soldes ouverts',open.length,'⇄','Éléments non soldés')}${stat('Éléments soldés',debts.length-open.length,'✓','Historique conservé')}</div><section class="panel table-panel"><div class="panel-header"><div><h2>Suivi des soldes</h2><p>Enregistrez un paiement pour actualiser le solde restant.</p></div><input class="table-search" id="listSearch" placeholder="Rechercher…" type="search"></div>${table(['Contact','Date','Montant initial','Déjà payé','Solde restant','Statut','Actions'],rows,empty('Aucun solde enregistré','Les créances créées par les ventes apparaîtront ici.'))}</section>`;
}
async function invoicesPage(){
 const sales=await get('sales');
 const rows=sales.map(s=>`<tr><td>${itemTitle('Document #'+s.id.slice(-7).toUpperCase(),s.productName)}</td><td>${E.esc(s.customerName||'Client de passage')}</td><td>${E.shortDate(s.date)}</td><td>${fmt(s.total)}</td><td>${badge(s.status||'Enregistrée',s.balance>0?'warning':'success')}</td><td><button class="btn btn-secondary btn-sm" data-print-sale="${s.id}">Voir / imprimer</button></td></tr>`);
 return heading('Factures & reçus','Les documents sont générés à partir des ventes enregistrées.')+`<div class="notice" style="margin-bottom:16px"><strong>À savoir :</strong> cette version génère des documents imprimables simples à partir des ventes. Vérifiez les obligations de facturation applicables à votre activité.</div><section class="panel table-panel"><div class="panel-header"><div><h2>Documents de vente</h2><p>${sales.length} document(s) disponible(s)</p></div><input class="table-search" id="listSearch" placeholder="Rechercher…" type="search"></div>${table(['Document','Client','Date','Total','Statut','Action'],rows,empty('Aucun document','Enregistrez une vente pour pouvoir générer un reçu.'))}</section>`;
}
async function reportsPage(){
 const [sales,expenses,products]=await Promise.all(['sales','expenses','products'].map(get));
 const byMonth={};sales.forEach(s=>{const k=E.monthKey(s.date);byMonth[k]??={sales:0,received:0,profit:0};byMonth[k].sales+=E.num(s.total);byMonth[k].received+=E.num(s.paid);byMonth[k].profit+=E.num(s.profit);});
 expenses.forEach(x=>{const k=E.monthKey(x.date);byMonth[k]??={sales:0,received:0,profit:0};byMonth[k].expenses=(byMonth[k].expenses||0)+E.num(x.amount);});
 const keys=Object.keys(byMonth).sort().reverse();const rows=keys.map(k=>{const x=byMonth[k];return `<tr><td><b>${E.esc(k)}</b></td><td>${fmt(x.sales)}</td><td>${fmt(x.received)}</td><td>${fmt(x.expenses||0)}</td><td><b>${fmt(x.profit-(x.expenses||0))}</b></td></tr>`;});
 const low=products.filter(p=>p.type!=='service'&&Number(p.stock||0)<=Number(p.lowStock??E.settings.lowStock));
 return heading('Rapports & statistiques','Analysez les résultats issus des opérations réellement enregistrées.',`<button class="btn btn-secondary" data-action="export-csv">⇩ Exporter les ventes CSV</button>`)+`<div class="grid stats-grid">${stat('Ventes totales',fmt(E.sum(sales,s=>s.total)),'↗','Depuis le début')}${stat('Paiements encaissés',fmt(E.sum(sales,s=>s.paid)),'✓','Depuis le début')}${stat('Dépenses totales',fmt(E.sum(expenses,x=>x.amount)),'↘','Depuis le début')}${stat('Alertes de stock',low.length,'▤','Produits au seuil ou en dessous')}</div><section class="panel table-panel"><div class="panel-header"><div><h2>Résultats par mois</h2><p>Les résultats estimés ne remplacent pas une comptabilité officielle.</p></div></div>${table(['Mois','Chiffre d’affaires','Encaissé','Dépenses','Résultat estimé'],rows,empty('Pas encore de données','Les rapports se rempliront avec les ventes et dépenses.'))}</section><div class="notice warning" style="margin-top:16px"><strong>Interprétation :</strong> le chiffre d’affaires correspond au total des ventes. Le montant encaissé correspond aux paiements enregistrés. Le résultat présenté est une estimation basée sur le bénéfice brut enregistré par vente moins les dépenses ajoutées. Les taxes, pertes, frais et autres ajustements non saisis ne sont pas calculés automatiquement.</div>`;
}
async function backupPage(){
 const [products,customers,sales,expenses]=await Promise.all(['products','customers','sales','expenses'].map(get));
 return heading('Sauvegarde & restauration','Protégez vos données et transférez-les vers un autre appareil.')+`<div class="section-grid"><section class="section-card"><div class="quick-icon">⇧</div><h3>Exporter une sauvegarde complète</h3><p>Téléchargez un fichier JSON contenant les produits, clients, ventes, stocks, dépenses, dettes, tâches, paramètres et informations de l’entreprise.</p><div class="metric-row"><span>Données principales</span><b>${products.length+customers.length+sales.length+expenses.length} éléments</b></div><button class="btn btn-accent" data-action="export-backup">Télécharger la sauvegarde</button></section><section class="section-card"><div class="quick-icon">⇩</div><h3>Restaurer une sauvegarde</h3><p>Importez un fichier JSON exporté par Gestion Business EDS. La restauration remplace les données locales correspondantes.</p><div class="notice warning" style="margin-bottom:14px"><strong>Attention :</strong> exportez d’abord une sauvegarde actuelle. L’importation peut remplacer vos données présentes.</div><button class="btn btn-secondary" data-action="import-backup">Choisir un fichier JSON</button></section></div><div class="notice" style="margin-top:16px"><strong>Conseil :</strong> conservez une copie de sauvegarde dans un emplacement sûr. Les données locales peuvent être perdues si l’application est désinstallée ou si les données de l’application sont effacées.</div>`;
}
async function settingsPage(){
 return heading('Paramètres','Personnalisez l’espace de travail selon votre activité.')+`<div class="settings-layout"><section class="section-card"><h3>Informations de l’entreprise</h3><p>Ces informations peuvent apparaître dans les documents générés.</p><form id="companyForm" class="form-grid">${field('Nom de l’entreprise','name',{required:true,value:E.company.name})}${field('Type d’activité','businessType',{value:E.company.businessType||'Commerce général'})}${field('Téléphone','phone',{type:'tel',value:E.company.phone})}${field('E-mail','email',{type:'email',value:E.company.email})}${field('Adresse','address',{value:E.company.address})}${field('NIF / identifiant fiscal','taxNumber',{value:E.company.taxNumber})}${field('Devise','currency',{type:'select',options:[{value:'HTG',label:'Gourde haïtienne (HTG)'},{value:'USD',label:'Dollar américain (USD)'},{value:'EUR',label:'Euro (EUR)'},{value:'CAD',label:'Dollar canadien (CAD)'}]})}<div class="field full"><button class="btn btn-accent" type="submit">Enregistrer les paramètres</button></div></form></section><section class="section-card"><h3>Préférences de l’application</h3><p>Réglez l’affichage et les seuils de suivi.</p><form id="prefsForm" class="form-grid">${field('Thème','theme',{type:'select',options:[{value:'light',label:'Clair'},{value:'dark',label:'Sombre'}]})}${field('Seuil de stock par défaut','lowStock',{type:'number',value:String(E.settings.lowStock||5),min:0,step:'1'})}<div class="field full"><button class="btn btn-accent" type="submit">Enregistrer les préférences</button></div></form><div class="notice" style="margin-top:18px"><strong>Application hors ligne :</strong> aucune synchronisation distante ni aucun compte en ligne ne sont nécessaires. Les données sont stockées sur cet appareil.</div></section></div>`;
}
async function aboutPage(){
 return heading('À propos de nous','Une application de gestion gratuite créée pour aider les entrepreneurs.')+`<section class="about-hero"><div class="about-logo">EDS</div><h2>Emerson Digital Solution</h2><p class="slogan">Des solutions digitales pour booster votre business en ligne</p><p>Nous créons des solutions numériques accessibles pour accompagner les entrepreneurs, les commerçants et les entreprises dans leur développement.</p><div style="margin-top:22px;display:flex;gap:10px;flex-wrap:wrap"><a class="btn btn-accent" href="https://emersondigitalsolution.vercel.app/" target="_blank" rel="noopener">Visiter notre site ↗</a><button class="btn btn-secondary" data-action="contact-copy">Copier le lien du site</button></div></section><div class="panel" style="margin-bottom:18px"><div class="panel-header"><div><h2>Nos services numériques</h2><p>Des solutions pour améliorer votre présence et vos outils digitaux.</p></div></div><div class="service-grid"><article class="service-card"><div class="service-icon">▣</div><h3>Création de sites web</h3><p>Sites vitrines, portfolios et plateformes adaptés aux besoins des entreprises.</p></article><article class="service-card"><div class="service-icon">✳</div><h3>Design graphique</h3><p>Logos, flyers, affiches, bannières et supports de communication visuelle.</p></article><article class="service-card"><div class="service-icon">▶</div><h3>Montage vidéo</h3><p>Création et montage de contenus vidéo pour les réseaux sociaux.</p></article><article class="service-card"><div class="service-icon">⌁</div><h3>Marketing digital</h3><p>Outils et supports pour présenter les activités et promouvoir les services.</p></article><article class="service-card"><div class="service-icon">▦</div><h3>Solutions numériques</h3><p>Conception d’outils numériques pratiques adaptés aux besoins des entrepreneurs.</p></article><article class="service-card"><div class="service-icon">↗</div><h3>Présence en ligne</h3><p>Accompagnement pour rendre une marque plus claire, cohérente et visible en ligne.</p></article></div></div><section class="panel"><div class="panel-header"><div><h2>À propos de Gestion Business EDS</h2><p>Votre gestion quotidienne, directement sur votre appareil.</p></div><span class="badge success">Gratuit · Hors ligne</span></div><p style="font-size:12px;color:var(--muted);line-height:1.8">Gestion Business EDS aide à organiser les ventes, produits, stocks, clients, fournisseurs, dépenses, soldes, tâches et rapports. Les informations sont conservées localement sur cet appareil. Cette application n’est pas un service de comptabilité certifiée et ne transmet pas vos données à Emerson Digital Solution.</p><div class="notice success"><strong>Créé par Emerson Digital Solution</strong><br>Des solutions digitales pour booster votre business en ligne.</div></section>`;
}
async function render(view){
 if(!views[view])view='dashboard';E.currentView=view;
 document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 $('#currentPageTitle').textContent=views[view][0];
 $('#companyNameSide').textContent=E.company.name;$('#profileCompany').textContent=E.company.name;
 let html='';
 if(view==='dashboard')html=await dashboard();
 else if(view==='sales')html=await salesPage();
 else if(view==='inventory')html=await inventoryPage();
 else if(view==='debts')html=await debtsPage();
 else if(view==='invoices')html=await invoicesPage();
 else if(view==='reports')html=await reportsPage();
 else if(view==='backup')html=await backupPage();
 else if(view==='settings')html=await settingsPage();
 else if(view==='about')html=await aboutPage();
 else html=await listingPage(view);
 root().innerHTML=html;
 bindView(view);
 if(view==='dashboard')drawChart();
}
function drawChart(){
 const canvas=$('#salesChart');if(!canvas)return;const ctx=canvas.getContext('2d');const rect=canvas.getBoundingClientRect();if(!rect.width)return;const dpr=window.devicePixelRatio||1;canvas.width=rect.width*dpr;canvas.height=rect.height*dpr;ctx.scale(dpr,dpr);
 const css=getComputedStyle(document.documentElement),line=css.getPropertyValue('--line').trim(),muted=css.getPropertyValue('--muted').trim(),green=css.getPropertyValue('--green-dark').trim();
 get('sales').then(sales=>{const vals=[];for(let i=5;i>=0;i--){const d=new Date();d.setDate(1);d.setMonth(d.getMonth()-i);const k=d.toISOString().slice(0,7);vals.push({label:d.toLocaleDateString('fr-FR',{month:'short'}),v:E.sum(sales.filter(s=>E.monthKey(s.date)===k),s=>s.total)});}
 const w=rect.width,h=rect.height,p={l:8,r:8,t:15,b:28},cw=w-p.l-p.r,ch=h-p.t-p.b,max=Math.max(1,...vals.map(x=>x.v));
 ctx.clearRect(0,0,w,h);ctx.font='10px system-ui';ctx.textAlign='center';vals.forEach((x,i)=>{const x0=p.l+(i+.5)*cw/vals.length,bh=x.v/max*(ch-10),bw=Math.min(26,cw/vals.length*.48),y=p.t+ch-bh;ctx.fillStyle=line;ctx.beginPath();ctx.roundRect(x0-bw/2,p.t,bw,ch,5);ctx.fill();ctx.fillStyle=green;ctx.beginPath();ctx.roundRect(x0-bw/2,y,bw,Math.max(3,bh),5);ctx.fill();ctx.fillStyle=muted;ctx.fillText(x.label,x0,h-7);if(x.v>0){ctx.fillStyle=muted;ctx.font='9px system-ui';ctx.fillText(x.v>=1000?(x.v/1000).toFixed(1)+'k':Math.round(x.v),x0,Math.max(10,y-5));ctx.font='10px system-ui';}});});
}
function bindView(view){
 const ls=$('#listSearch');if(ls)ls.addEventListener('input',()=>{const q=ls.value.toLocaleLowerCase('fr');root().querySelectorAll('tbody tr').forEach(tr=>tr.classList.toggle('hidden',!tr.textContent.toLocaleLowerCase('fr').includes(q)));});
 const cf=$('#companyForm');if(cf){cf.querySelector('[name=currency]').value=E.company.currency||E.settings.currency||'HTG';cf.addEventListener('submit',async ev=>{ev.preventDefault();const d=Object.fromEntries(new FormData(cf));await E.setCompany(d);await E.setSettings({currency:d.currency});await render('settings');E.toast('Informations enregistrées.');});}
 const pf=$('#prefsForm');if(pf){pf.querySelector('[name=theme]').value=E.settings.theme||'light';pf.addEventListener('submit',async ev=>{ev.preventDefault();const d=Object.fromEntries(new FormData(pf));d.lowStock=Number(d.lowStock||5);await E.setSettings(d);await render('settings');E.toast('Préférences enregistrées.');});}
}
async function handleAction(action){
 if(action==='new-sale')return openSaleForm();
 if(action==='new-product')return openEntityForm('products');
 if(action==='new-customer')return openEntityForm('customers');
 if(action==='new-supplier')return openEntityForm('suppliers');
 if(action==='new-expense')return openEntityForm('expenses');
 if(action==='new-task')return openEntityForm('tasks');
 if(action==='new-debt')return openDebtForm();
 if(action==='export-backup')return exportBackup();
 if(action==='import-backup')return $('#importFile').click();
 if(action==='export-csv')return exportCSV();
 if(action==='contact-copy'){try{await navigator.clipboard.writeText('https://emersondigitalsolution.vercel.app/');E.toast('Lien copié.');}catch(e){E.toast('Site : https://emersondigitalsolution.vercel.app/');}}
}
async function openDebtForm(){
 const customers=await get('customers'),suppliers=await get('suppliers');
 modal('Ajouter une dette ou créance','Enregistrez un solde initial à suivre.',`<div class="form-grid">${field('Type','type',{type:'select',options:[{value:'Créance client',label:'Créance client (à recevoir)'},{value:'Dette fournisseur',label:'Dette fournisseur (à payer)'}]})}${field('Contact','partyId',{type:'select',options:[{value:'',label:'Autre contact'},...customers.map(c=>({value:c.id,label:'Client : '+c.name})),...suppliers.map(s=>({value:s.id,label:'Fournisseur : '+s.name}))]})}${field('Nom du contact','partyName',{required:true})}${field('Montant initial','amount',{type:'number',required:true,min:.01,step:'0.01'})}${field('Date','date',{type:'date',required:true,value:E.today()})}${field('Échéance','dueDate',{type:'date'})}${field('Note','note',{type:'textarea',full:true})}</div>`,'Enregistrer le solde',async d=>{const amount=Number(d.amount);if(amount<=0)throw new Error('Le montant doit être supérieur à zéro.');await E.save('debts',{id:E.id(),...d,amount,paid:0,balance:amount,status:d.type==='Dette fournisseur'?'À payer':'À recevoir'});});
}
async function exportBackup(){
 const payload=await E.exportData(),blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='gestion-business-eds-sauvegarde-'+E.today()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);E.toast('Sauvegarde préparée.');
}
async function exportCSV(){
 const sales=await get('sales'),headers=['ID','Date','Produit','Client','Quantité','Prix unitaire','Réduction','Total','Payé','Solde','Bénéfice estimé','Mode de paiement'];
 const rows=sales.map(s=>[s.id,s.date,s.productName,s.customerName,s.quantity,s.unitPrice,s.discount,s.total,s.paid,s.balance,s.profit,s.method]);
 const csv=[headers,...rows].map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');
 const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ventes-eds-'+E.today()+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);E.toast('Export CSV prêt.');
}
async function printSale(id){
 const s=(await get('sales')).find(x=>x.id===id);if(!s)return;
 const w=window.open('','_blank');if(!w){E.toast('Autorisez les fenêtres d’impression dans le navigateur.','error');return;}
 w.document.write(`<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Document de vente</title><style>body{font:14px Arial,sans-serif;color:#17213b;margin:35px}.top{display:flex;justify-content:space-between;border-bottom:3px solid #a3f635;padding-bottom:18px}.brand{font-size:20px;font-weight:bold}.muted{color:#68758d;font-size:12px}.box{border:1px solid #ddd;padding:15px;border-radius:10px;margin:20px 0}table{width:100%;border-collapse:collapse;margin:25px 0}td,th{padding:12px;border-bottom:1px solid #ddd;text-align:left}th{background:#f5f7fa}.total{text-align:right;font-size:18px;font-weight:bold}.footer{margin-top:45px;font-size:11px;color:#68758d;text-align:center}</style></head><body><div class="top"><div><div class="brand">${E.esc(E.company.name)}</div><p class="muted">${E.esc(E.company.address||'')}${E.company.phone?' · '+E.esc(E.company.phone):''}</p><p class="muted">${E.esc(E.company.email||'')}</p></div><div style="text-align:right"><h2>${s.balance>0?'FACTURE / REÇU':'REÇU DE PAIEMENT'}</h2><p>Document #${s.id.slice(-7).toUpperCase()}</p><p>${E.shortDate(s.date)}</p></div></div><div class="box"><b>Client :</b> ${E.esc(s.customerName||'Client de passage')}<br><b>Statut :</b> ${E.esc(s.status||'Enregistrée')}</div><table><thead><tr><th>Description</th><th>Qté</th><th>Prix unitaire</th><th>Total</th></tr></thead><tbody><tr><td>${E.esc(s.productName)}</td><td>${s.quantity}</td><td>${fmt(s.unitPrice)}</td><td>${fmt(s.quantity*s.unitPrice)}</td></tr></tbody></table><p class="total">Sous-total : ${fmt(s.quantity*s.unitPrice)}</p><p class="total">Réduction : − ${fmt(s.discount)}</p><p class="total">Total : ${fmt(s.total)}</p><p class="total">Payé : ${fmt(s.paid)}</p><p class="total">Solde : ${fmt(s.balance)}</p><div class="footer">Créé avec Gestion Business EDS · Emerson Digital Solution</div><script>window.onload=()=>window.print();</script></body></html>`);
 w.document.close();
}
async function deleteEntity(store,id){
 const item=(await get(store)).find(x=>x.id===id);if(!item)return;
 askConfirm(`Voulez-vous supprimer « ${item.name||item.productName||item.partyName||'cet élément'} » ?`,async()=>{
  if(store==='products'&&item.type!=='service'){const sales=await get('sales');if(sales.some(s=>s.productId===id))throw new Error('Ce produit est lié à des ventes. Conservez-le pour préserver l’historique.');}
  await E.remove(store,id);
  await render(E.currentView);E.toast('Élément supprimé.');
 });
}
async function editEntity(store,id){
 if(['products','customers','suppliers','expenses','tasks'].includes(store))return openEntityForm(store,id);
 const item=(await get(store)).find(x=>x.id===id);if(!item)return;
 if(store==='sales'){modal('Détails de la vente','Les ventes enregistrées ne sont pas modifiables pour protéger les stocks et l’historique.',`<div class="notice"><strong>${E.esc(item.productName)}</strong><br>Client : ${E.esc(item.customerName)}<br>Date : ${E.shortDate(item.date)}<br>Total : ${fmt(item.total)}<br>Payé : ${fmt(item.paid)}<br>Solde : ${fmt(item.balance)}</div>`,'Fermer',async()=>{});return;}
 if(store==='debts')return modal('Détails du solde','Utilisez le bouton Paiement pour réduire le solde.',`<div class="notice"><strong>${E.esc(item.partyName)}</strong><br>${E.esc(item.type)}<br>Initial : ${fmt(item.amount)}<br>Payé : ${fmt(item.paid)}<br>Reste : ${fmt(item.balance??item.amount)}</div>`,'Fermer',async()=>{});
}
async function globalSearch(q){
 if(!q||q.length<2)return;
 const map=[['products','products'],['customers','customers'],['suppliers','suppliers'],['sales','sales'],['expenses','expenses'],['debts','debts'],['tasks','tasks']];
 const results=[];
 for(const [store,view] of map){const arr=await get(store);arr.forEach(x=>{if(Object.values(x).some(v=>String(v??'').toLocaleLowerCase('fr').includes(q.toLocaleLowerCase('fr'))))results.push({store,view,item:x});});}
 if(!results.length){E.toast('Aucun résultat trouvé.','error');return;}
 const groups={};results.slice(0,30).forEach(r=>(groups[r.view]??=[]).push(r));
 const body=Object.entries(groups).map(([v,rs])=>`<div style="margin-bottom:14px"><div class="eyebrow">${views[v]?.[0]||v}</div>${rs.map(r=>`<button class="quick-action" style="width:100%;margin-bottom:6px" data-search-result="${v}"><span class="quick-icon">⌕</span><span><strong>${E.esc(r.item.name||r.item.productName||r.item.partyName||'Élément')}</strong><small>${E.esc(r.item.phone||r.item.customerName||r.item.category||r.item.type||'')}</small></span></button>`).join('')}</div>`).join('');
 modal('Résultats de recherche',`${results.length} résultat(s) trouvé(s)`,body,'Fermer',async()=>{});
 document.querySelectorAll('[data-search-result]').forEach(b=>b.addEventListener('click',async()=>{document.querySelectorAll('[data-search-result]').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#modalRoot').innerHTML='';await render(b.dataset.searchResult);}));
}
document.addEventListener('click',async ev=>{
 const nav=ev.target.closest('[data-nav]');if(nav){await render(nav.dataset.nav);return;}
 const act=ev.target.closest('[data-action]');if(act){await handleAction(act.dataset.action);return;}
 const edit=ev.target.closest('[data-edit]');if(edit){await editEntity(edit.dataset.edit,edit.dataset.id);return;}
 const del=ev.target.closest('[data-delete]');if(del){await deleteEntity(del.dataset.delete,del.dataset.id);return;}
 const pay=ev.target.closest('[data-payment]');if(pay){await paymentForm(pay.dataset.payment);return;}
 const print=ev.target.closest('[data-print-sale]');if(print){await printSale(print.dataset.printSale);return;}
 const toggle=ev.target.closest('[data-toggle-task]');if(toggle){const task=(await get('tasks')).find(t=>t.id===toggle.dataset.toggleTask);if(task){task.status=task.status==='Terminée'?'À faire':'Terminée';await E.save('tasks',task);await render(E.currentView);E.toast('Statut de la tâche mis à jour.');}return;}
});
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',async()=>{await render(b.dataset.view);$('#sidebar').classList.remove('open');}));
$('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#editCompanyBtn').addEventListener('click',()=>render('settings'));
$('#profileButton').addEventListener('click',()=>render('settings'));
$('#themeToggle').addEventListener('click',async()=>{await E.setSettings({theme:E.settings.theme==='dark'?'light':'dark'});await render(E.currentView);});
$('#globalSearch').addEventListener('keydown',ev=>{if(ev.key==='Enter'){globalSearch(ev.target.value.trim());ev.target.blur();}});
$('#importFile').addEventListener('change',async ev=>{const f=ev.target.files?.[0];if(!f)return;try{const payload=JSON.parse(await f.text());if(!confirm('Cette restauration peut remplacer vos données locales. Continuer ?'))return;await E.importData(payload);await render('dashboard');E.toast('Sauvegarde restaurée.');}catch(err){E.toast(err.message||'Impossible de lire la sauvegarde.','error');}finally{ev.target.value='';}});
window.EDSModules={render,drawChart};
})();