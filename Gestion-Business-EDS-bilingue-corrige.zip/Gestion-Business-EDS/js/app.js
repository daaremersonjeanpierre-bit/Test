(async function(){
  await window.EDS.init();
  await window.EDSModules.render('dashboard');
  window.addEventListener('resize',()=>{if(window.EDS.currentView==='dashboard')window.EDSModules.drawChart();});
  // Small keyboard shortcut: Escape closes modal and mobile navigation.
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.getElementById('modalRoot').innerHTML='';document.getElementById('sidebar').classList.remove('open');}});
})();