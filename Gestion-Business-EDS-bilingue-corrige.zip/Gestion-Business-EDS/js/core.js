/* Gestion Business EDS — stockage local, utilitaires et règles communes. */
(function(){
  const DB_NAME='gestion_business_eds', DB_VERSION=1;
  const STORES=['products','customers','suppliers','sales','expenses','debts','tasks','settings','company'];
  let db=null;
  const memory={};
  function openDB(){
    return new Promise((resolve,reject)=>{
      if(!('indexedDB' in window)){resolve(null);return;}
      const req=indexedDB.open(DB_NAME,DB_VERSION);
      req.onupgradeneeded=()=>{const d=req.result;STORES.forEach(s=>{if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:'id'});});};
      req.onsuccess=()=>{db=req.result;resolve(db);};
      req.onerror=()=>resolve(null);
    });
  }
  async function getStore(name){
    if(!db) await openDB();
    if(db && db.objectStoreNames.contains(name)){
      return new Promise((resolve,reject)=>{const tx=db.transaction(name,'readonly');const r=tx.objectStore(name).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});
    }
    try{return JSON.parse(localStorage.getItem('eds_'+name)||'[]');}catch(e){return memory[name]||[];}
  }
  async function putStore(name,items){
    if(!db) await openDB();
    if(db && db.objectStoreNames.contains(name)){
      return new Promise((resolve,reject)=>{const tx=db.transaction(name,'readwrite'),st=tx.objectStore(name);st.clear();items.forEach(x=>st.put(x));tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error);});
    }
    try{localStorage.setItem('eds_'+name,JSON.stringify(items));}catch(e){memory[name]=items;}
    return true;
  }
  const id=()=>Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9);
  const today=()=>new Date().toISOString().slice(0,10);
  const dateTime=()=>new Date().toISOString();
  const num=v=>Number.isFinite(Number(v))?Number(v):0;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const currency=(value,code)=>{let c=code||App.company?.currency||'HTG';try{return new Intl.NumberFormat('fr-FR',{style:'currency',currency:c,maximumFractionDigits:2}).format(num(value));}catch(e){return num(value).toLocaleString('fr-FR',{maximumFractionDigits:2})+' '+c;}};
  const shortDate=v=>{if(!v)return '—';let d=new Date(v+'T12:00:00');return Number.isNaN(d.getTime())?v:d.toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'});};
  const monthKey=v=>(v||today()).slice(0,7);
  const sum=(arr,fn)=>arr.reduce((a,x)=>a+num(fn(x)),0);
  const toast=(message,type='success')=>{const root=document.getElementById('toastRoot');if(!root)return;const el=document.createElement('div');el.className='toast '+type;el.textContent=message;root.appendChild(el);setTimeout(()=>el.remove(),3500);};
  const all=async name=>getStore(name);
  const save=async(name,item)=>{const arr=await getStore(name);const idx=arr.findIndex(x=>x.id===item.id);if(idx>=0)arr[idx]={...arr[idx],...item,updatedAt:dateTime()};else arr.unshift({...item,id:item.id||id(),createdAt:item.createdAt||dateTime(),updatedAt:dateTime()});await putStore(name,arr);return item;};
  const remove=async(name,itemId)=>{const arr=await getStore(name);await putStore(name,arr.filter(x=>x.id!==itemId));};
  const replace=async(name,items)=>putStore(name,items);
  const defaultCompany={id:'main-company',name:'Mon entreprise',owner:'Emerson Digital Solution',phone:'',email:'',address:'',currency:'HTG',businessType:'Commerce général',taxNumber:'',logoText:'EDS'};
  const defaultSettings={id:'main-settings',theme:'light',currency:'HTG',lowStock:5,showWelcome:true};
  const App={
    id,today,dateTime,num,esc,currency,shortDate,monthKey,sum,toast,all,save,remove,replace,
    company:{...defaultCompany},settings:{...defaultSettings},currentView:'dashboard',
    async init(){await openDB();const cs=await all('company');if(cs[0])this.company={...defaultCompany,...cs[0]};else await save('company',defaultCompany);
      const ss=await all('settings');if(ss[0])this.settings={...defaultSettings,...ss[0]};else await save('settings',defaultSettings);
      document.documentElement.dataset.theme=this.settings.theme||'light';return true;},
    async setCompany(data){this.company={...this.company,...data,id:'main-company'};await replace('company',[this.company]);},
    async setSettings(data){this.settings={...this.settings,...data,id:'main-settings'};await replace('settings',[this.settings]);document.documentElement.dataset.theme=this.settings.theme||'light';},
    async exportData(){const out={app:'Gestion Business EDS',schemaVersion:1,exportedAt:dateTime(),company:this.company,settings:this.settings,data:{}};for(const s of STORES)out.data[s]=await all(s);return out;},
    async importData(payload){if(!payload||!payload.data||typeof payload.data!=='object')throw new Error('Fichier de sauvegarde non reconnu.');for(const s of STORES){if(Array.isArray(payload.data[s]))await replace(s,payload.data[s]);}if(payload.company)this.company={...defaultCompany,...payload.company};if(payload.settings)this.settings={...defaultSettings,...payload.settings};await replace('company',[this.company]);await replace('settings',[this.settings]);}
  };
  window.EDS=App;
})();